import React from "react";

const TermsOfService = () => {
  return (
    <div>
      <h1>ข้อกำหนดของบริการ</h1>
      <p>นี่คือข้อกำหนดของบริการของเรา...</p>
    </div>
  );
};

export default TermsOfService;
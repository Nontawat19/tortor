import React from "react";

const UserDataDeletion = () => {
  return (
    <div>
      <h1>การลบข้อมูลผู้ใช้</h1>
      <p>นี่คือขั้นตอนการลบข้อมูลผู้ใช้...</p>
    </div>
  );
};

export default UserDataDeletion;
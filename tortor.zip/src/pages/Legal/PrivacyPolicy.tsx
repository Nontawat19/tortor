import React from "react";

const PrivacyPolicy = () => {
  return (
    <div>
      <h1>นโยบายความเป็นส่วนตัว</h1>
      <p>นี่คือนโยบายความเป็นส่วนตัวของเรา...</p>
    </div>
  );
};

export default PrivacyPolicy;
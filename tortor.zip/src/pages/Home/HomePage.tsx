import React from "react";
import Navbar from "@/components/Navbar/Navbar";
import LeftSidebar from "@/components/Sidebar/LeftSidebar";
import RightSidebar from "@/components/Sidebar/RightSidebar";
import PostCreator from "@/components/Post/PostCreator";
import PostList from "@/components/Post/PostList";

import "@/styles/HomePage.css";

const HomePage: React.FC = () => {
  return (
    <div className="home-wrapper">
      <Navbar />
      <div className="home-content">
        <div className="home-sidebar-left">
          <LeftSidebar />
        </div>

        <div className="home-feed">
          <PostCreator />
          <PostList />
        </div>

        <div className="home-sidebar-right">
          <RightSidebar />
        </div>
      </div>
    </div>
  );
};

export default HomePage;
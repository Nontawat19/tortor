import React from "react";
import Navbar from "../components/Navbar/Navbar";

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  return (
    <>
      <Navbar />
      <div style={{ 
        paddingTop: "80px", 
        display: "flex", 
        justifyContent: "center", 
        backgroundColor: "#f0f2f5", 
        minHeight: "100vh" 
      }}>
        {children}
      </div>
    </>
  );
};

export default MainLayout;

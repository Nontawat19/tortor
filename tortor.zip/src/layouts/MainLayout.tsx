import React from "react";
import Navbar from "../components/Navbar/Navbar";

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  return (
    <>
      <Navbar />
      <div
        className="layout-wrapper"
        style={{
          backgroundColor: "#18191a",
          minHeight: "100vh",
          paddingTop: "56px",
        }}
      >
        {children}
      </div>
    </>
  );
};

export default MainLayout;

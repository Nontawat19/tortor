import React from 'react';

const PostList: React.FC = () => {
  return (
    <div className="text-white mt-8">
      <p>ยังไม่มีโพสต์ในระบบ</p>
    </div>
  );
};

export default PostList;
